"""Modèle de domaine : rôles, permissions, entités et schémas d'API.

Les dataclasses portent le domaine (Chapitre 2 : typage statique, contrats clairs) ;
les modèles Pydantic valident les entrées HTTP (Chapitre 5, section 5.7.1).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Role(str, Enum):
    ADMIN = "admin"
    ANALYSTE = "analyste"
    UTILISATEUR = "utilisateur"

    @classmethod
    def _missing_(cls, value):
        # Compatibilité : l'ancien nom du rôle était « lecteur ».
        if value == "lecteur":
            return cls.UTILISATEUR
        return None


class Permission(str, Enum):
    DASHBOARD_READ = "dashboard:read"
    DASHBOARD_WRITE = "dashboard:write"
    DASHBOARD_DELETE = "dashboard:delete"
    ACCESS_GRANT = "access:grant"
    USER_MANAGE = "user:manage"
    AUDIT_READ = "audit:read"


class AccessLevel(int, Enum):
    """Niveau d'accès accordé sur UN tableau de bord (ordonné : WRITE inclut READ)."""
    READ = 1
    WRITE = 2


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class User:
    id: int
    username: str
    password_hash: str
    role: Role = Role.UTILISATEUR
    failed_attempts: int = 0
    locked_until: Optional[datetime] = None
    active: bool = True


@dataclass
class Dashboard:
    id: int
    name: str
    owner_id: int
    description: str = ""


@dataclass(frozen=True)
class Grant:
    user_id: int
    dashboard_id: int
    level: AccessLevel


@dataclass(frozen=True)
class AuditEvent:
    action: str
    actor: str
    target: str = ""
    success: bool = True
    at: datetime = field(default_factory=utcnow)


# ---------- Schémas d'API (validation automatique) ----------

class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=8, max_length=128)
    role: Optional[Role] = None  # choix du rôle à la création du compte (voir Settings.allow_role_choice)


class LoginIn(BaseModel):
    username: str
    password: str


class RefreshIn(BaseModel):
    refresh_token: str


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: int
    username: str
    role: Role


class RoleIn(BaseModel):
    role: Role


class DashboardIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=500)


class DashboardOut(BaseModel):
    id: int
    name: str
    owner_id: int
    description: str
    owner_name: str = ""
    my_access: str = ""  # « propriétaire », « administrateur », « écriture » ou « lecture »


class GrantIn(BaseModel):
    user_id: int
    level: AccessLevel


class GrantOut(BaseModel):
    user_id: int
    username: str
    level: str  # « lecture » ou « écriture »


class AuditOut(BaseModel):
    action: str
    actor: str
    target: str
    success: bool
    at: datetime


class PermissionInfo(BaseModel):
    code: str
    label: str


class RoleInfo(BaseModel):
    code: str
    label: str
    description: str
    permissions: list[str]


class RolesOut(BaseModel):
    permissions: list[PermissionInfo]
    roles: list[RoleInfo]
