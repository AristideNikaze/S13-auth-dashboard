"""Contrôle d'accès : RBAC (rôle -> permissions) + ACL par tableau de bord.

Règle de décision, évaluée dans cet ordre :
 1. le rôle doit posséder la permission demandée ;
 2. ADMIN : accès à tout ;
 3. propriétaire du tableau de bord : accès ;
 4. sinon, un Grant explicite de niveau suffisant est exigé.
"""
from __future__ import annotations

from typing import Iterable, Optional

from .models import AccessLevel, Dashboard, Grant, Permission, Role, User

ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.ADMIN: frozenset(Permission),
    Role.ANALYSTE: frozenset({
        Permission.DASHBOARD_READ,
        Permission.DASHBOARD_WRITE,
        Permission.ACCESS_GRANT,
    }),
    Role.UTILISATEUR: frozenset({Permission.DASHBOARD_READ}),
}

# ---- libellés français (messages d'erreur et interface) ----
ROLE_LABELS: dict[Role, str] = {
    Role.ADMIN: "Administrateur",
    Role.ANALYSTE: "Analyste",
    Role.UTILISATEUR: "Utilisateur",
}

ROLE_DESCRIPTIONS: dict[Role, str] = {
    Role.ADMIN: "Accès total : gère les rôles, supprime, consulte le journal d'audit.",
    Role.ANALYSTE: "Crée, modifie et partage des tableaux de bord.",
    Role.UTILISATEUR: "Consulte uniquement les tableaux de bord partagés avec lui.",
}

PERMISSION_LABELS: dict[Permission, str] = {
    Permission.DASHBOARD_READ: "Consulter un tableau de bord",
    Permission.DASHBOARD_WRITE: "Créer ou modifier un tableau de bord",
    Permission.DASHBOARD_DELETE: "Supprimer un tableau de bord",
    Permission.ACCESS_GRANT: "Partager un tableau de bord",
    Permission.USER_MANAGE: "Gérer les rôles des utilisateurs",
    Permission.AUDIT_READ: "Consulter le journal d'audit",
}

_REQUIRED_LEVEL = {
    Permission.DASHBOARD_READ: AccessLevel.READ,
    Permission.DASHBOARD_WRITE: AccessLevel.WRITE,
    Permission.DASHBOARD_DELETE: AccessLevel.WRITE,
    Permission.ACCESS_GRANT: AccessLevel.WRITE,
}


def has_permission(role: Role, permission: Permission) -> bool:
    return permission in ROLE_PERMISSIONS[role]


def roles_with(permission: Permission) -> list[Role]:
    return [r for r in Role if has_permission(r, permission)]


def forbidden_message(role: Role, permission: Permission) -> str:
    """Message clair affiché à l'utilisateur quand son rôle n'a pas la permission."""
    allowed = ", ".join(ROLE_LABELS[r].lower() for r in roles_with(permission))
    return (f"Accès refusé : le rôle « {ROLE_LABELS[role].lower()} » n'a pas le droit de "
            f"{PERMISSION_LABELS[permission].lower()}. Rôle(s) autorisé(s) : {allowed}.")


def can_access(user: User, permission: Permission, dashboard: Dashboard, grants: Iterable[Grant]) -> bool:
    if not user.active or not has_permission(user.role, permission):
        return False
    if user.role is Role.ADMIN or dashboard.owner_id == user.id:
        return True
    required = _REQUIRED_LEVEL.get(permission)
    if required is None:
        return False
    best: Optional[AccessLevel] = max(
        (g.level for g in grants if g.user_id == user.id and g.dashboard_id == dashboard.id),
        default=None,
        key=lambda lvl: lvl.value,
    )
    return best is not None and best.value >= required.value
