"""Logique métier : inscription, authentification, jetons, droits, audit.

Aucune dépendance à FastAPI : le service se teste sans serveur HTTP (pyramide des tests, Chapitre 9).
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Callable, Optional

from . import security
from .config import Settings
from .models import AccessLevel, AuditEvent, Dashboard, Grant, Permission, Role, User, utcnow
from .rbac import can_access, forbidden_message, has_permission
from .repository import Repository

# Hash factice : comparé même si l'utilisateur n'existe pas, pour égaliser les temps de réponse
# (évite l'énumération de comptes par mesure du temps).
_DUMMY_HASH = security.hash_password("Dummy-Password-1")


class AuthError(Exception):
    """Identifiants invalides, compte verrouillé ou jeton refusé -> HTTP 401."""


class ForbiddenError(Exception):
    """Authentifié mais non autorisé -> HTTP 403."""


class NotFoundError(Exception):
    """Ressource inexistante -> HTTP 404."""


class ConflictError(Exception):
    """Conflit (nom d'utilisateur déjà pris) -> HTTP 409."""


class AuthService:
    def __init__(self, repo: Repository, settings: Settings, clock: Callable[[], datetime] = utcnow) -> None:
        self.repo = repo
        self.settings = settings
        self.clock = clock  # injectable : permet de simuler le temps dans les tests

    # ---------------- comptes ----------------
    def register(self, username: str, password: str, role: Optional[Role] = None) -> User:
        security.validate_password_policy(password)
        if self.repo.get_user_by_name(username):
            self.repo.log(AuditEvent("register", username, success=False))
            raise ConflictError("Ce nom d'utilisateur est déjà utilisé")
        if role is not None and self.settings.allow_role_choice:
            chosen = role  # mode démonstration : le rôle est choisi à la création du compte
        else:
            # Sans choix : le tout premier compte devient administrateur (amorçage), les suivants sont utilisateurs.
            chosen = Role.ADMIN if self.repo.count_users() == 0 else Role.UTILISATEUR
        role = chosen
        user = self.repo.add_user(username, security.hash_password(password), role)
        self.repo.log(AuditEvent("register", username, target=role.value))
        return user

    def login(self, username: str, password: str) -> tuple[str, str]:
        user = self.repo.get_user_by_name(username)
        now = self.clock()
        if user is None:
            security.verify_password(password, _DUMMY_HASH)
            self.repo.log(AuditEvent("login", username, success=False))
            raise AuthError("Nom d'utilisateur ou mot de passe incorrect.")
        if user.locked_until and user.locked_until > now:
            self.repo.log(AuditEvent("login_locked", username, success=False))
            raise AuthError("Compte temporairement verrouillé après trop d'échecs. Réessayez dans 15 minutes.")
        if not user.active or not security.verify_password(password, user.password_hash):
            user.failed_attempts += 1
            if user.failed_attempts >= self.settings.max_failed_attempts:
                user.locked_until = now + timedelta(seconds=self.settings.lockout_seconds)
                user.failed_attempts = 0
                self.repo.log(AuditEvent("account_locked", username, success=False))
            self.repo.update_user(user)  # persiste compteur / verrou (indispensable avec une vraie base)
            self.repo.log(AuditEvent("login", username, success=False))
            raise AuthError("Nom d'utilisateur ou mot de passe incorrect.")
        if user.failed_attempts or user.locked_until:
            user.failed_attempts = 0
            user.locked_until = None
            self.repo.update_user(user)
        self.repo.log(AuditEvent("login", username))
        return self._issue_pair(user)

    def _issue_pair(self, user: User) -> tuple[str, str]:
        now = self.clock()
        args = dict(user_id=user.id, role=user.role.value, settings=self.settings, now=now)
        return (security.create_token(kind=security.ACCESS, **args),
                security.create_token(kind=security.REFRESH, **args))

    def refresh(self, refresh_token: str) -> tuple[str, str]:
        payload = self._decode(refresh_token, security.REFRESH)
        user = self.repo.get_user(int(payload["sub"]))
        if user is None or not user.active:
            raise AuthError("Compte inconnu.")
        self.repo.revoke_token(payload["jti"])  # rotation : un refresh token ne sert qu'une fois
        self.repo.log(AuditEvent("refresh", user.username))
        return self._issue_pair(user)

    def logout(self, access_token: str) -> None:
        payload = self._decode(access_token, security.ACCESS)
        self.repo.revoke_token(payload["jti"])
        user = self.repo.get_user(int(payload["sub"]))
        self.repo.log(AuditEvent("logout", user.username if user else "?"))

    def _decode(self, token: str, kind: str) -> dict:
        try:
            payload = security.decode_token(token, expected_kind=kind, settings=self.settings,
                                            now=self.clock())
        except security.InvalidTokenError as exc:
            raise AuthError(str(exc)) from exc
        if self.repo.is_revoked(payload["jti"]):
            raise AuthError("Session terminée (jeton révoqué). Reconnectez-vous.")
        return payload

    def authenticate(self, access_token: str) -> User:
        """Jeton d'accès -> utilisateur COURANT relu en base (le rôle du jeton n'est pas cru sur parole)."""
        payload = self._decode(access_token, security.ACCESS)
        user = self.repo.get_user(int(payload["sub"]))
        if user is None or not user.active:
            raise AuthError("Compte inconnu ou désactivé.")
        return user

    # ---------------- administration ----------------
    def set_role(self, actor: User, target_id: int, role: Role) -> User:
        self._require(actor, Permission.USER_MANAGE)
        target = self.repo.get_user(target_id)
        if target is None:
            raise NotFoundError("Utilisateur introuvable")
        if target.id == actor.id and role is not Role.ADMIN:
            raise ForbiddenError("Action refusée : un administrateur ne peut pas se rétrograder lui-même.")
        target.role = role
        self.repo.update_user(target)
        self.repo.log(AuditEvent("set_role", actor.username, f"{target.username}->{role.value}"))
        return target

    def list_users(self, actor: User) -> list[User]:
        """Annuaire (id, nom, rôle) : nécessaire pour choisir avec qui partager ; aucune donnée sensible."""
        return self.repo.list_users()

    def audit(self, actor: User) -> list[AuditEvent]:
        self._require(actor, Permission.AUDIT_READ)
        return self.repo.audit_events()

    def _require(self, user: User, permission: Permission) -> None:
        if not user.active or not has_permission(user.role, permission):
            self.repo.log(AuditEvent("denied", user.username, permission.value, success=False))
            raise ForbiddenError(forbidden_message(user.role, permission))

    # ---------------- tableaux de bord ----------------
    def create_dashboard(self, actor: User, name: str, description: str) -> Dashboard:
        self._require(actor, Permission.DASHBOARD_WRITE)
        dash = self.repo.add_dashboard(name, actor.id, description)
        self.repo.log(AuditEvent("dashboard_create", actor.username, str(dash.id)))
        return dash

    def list_dashboards(self, actor: User) -> list[Dashboard]:
        grants = self.repo.all_grants()
        return [d for d in self.repo.list_dashboards()
                if can_access(actor, Permission.DASHBOARD_READ, d, grants)]

    def _authorized_dashboard(self, actor: User, dashboard_id: int, permission: Permission) -> Dashboard:
        # 1) le RÔLE : refus net et explicite, avant même de regarder si le tableau existe.
        self._require(actor, permission)
        dash = self.repo.get_dashboard(dashboard_id)
        # 2) la VISIBILITÉ : 404 si le tableau n'existe pas OU n'est pas partagé avec l'utilisateur
        #    (on ne révèle pas l'existence d'une ressource interdite).
        if dash is None or not can_access(actor, Permission.DASHBOARD_READ, dash, self.repo.grants_for(dash.id)):
            raise NotFoundError("Tableau de bord introuvable ou non partagé avec vous.")
        # 3) le NIVEAU d'accès sur ce tableau (lecture seule / écriture).
        if not can_access(actor, permission, dash, self.repo.grants_for(dash.id)):
            self.repo.log(AuditEvent("denied", actor.username, f"{permission.value}:{dash.id}", success=False))
            raise ForbiddenError("Accès refusé : ce tableau est partagé avec vous en lecture seule. "
                                 "Le droit d'écriture est nécessaire pour cette action.")
        return dash

    def access_label(self, actor: User, dash: Dashboard) -> str:
        """Ce que l'utilisateur est à l'égard de ce tableau (affiché dans l'interface)."""
        if actor.role is Role.ADMIN:
            return "administrateur"
        if dash.owner_id == actor.id:
            return "propriétaire"
        levels = [g.level for g in self.repo.grants_for(dash.id) if g.user_id == actor.id]
        if levels and max(levels, key=lambda lv: lv.value) is AccessLevel.WRITE:
            return "écriture"
        return "lecture"

    def list_grants(self, actor: User, dashboard_id: int) -> list[tuple[Grant, Optional[User]]]:
        dash = self._authorized_dashboard(actor, dashboard_id, Permission.DASHBOARD_READ)
        return [(g, self.repo.get_user(g.user_id)) for g in self.repo.grants_for(dash.id)]

    def get_dashboard(self, actor: User, dashboard_id: int) -> Dashboard:
        return self._authorized_dashboard(actor, dashboard_id, Permission.DASHBOARD_READ)

    def update_dashboard(self, actor: User, dashboard_id: int, name: str, description: str) -> Dashboard:
        dash = self._authorized_dashboard(actor, dashboard_id, Permission.DASHBOARD_WRITE)
        dash.name, dash.description = name, description
        self.repo.update_dashboard(dash)
        self.repo.log(AuditEvent("dashboard_update", actor.username, str(dash.id)))
        return dash

    def delete_dashboard(self, actor: User, dashboard_id: int) -> None:
        dash = self._authorized_dashboard(actor, dashboard_id, Permission.DASHBOARD_DELETE)
        self.repo.delete_dashboard(dash.id)
        self.repo.log(AuditEvent("dashboard_delete", actor.username, str(dash.id)))

    def grant(self, actor: User, dashboard_id: int, user_id: int, level: AccessLevel) -> Grant:
        dash = self._authorized_dashboard(actor, dashboard_id, Permission.ACCESS_GRANT)
        if self.repo.get_user(user_id) is None:
            raise NotFoundError("Utilisateur introuvable")
        grant = Grant(user_id, dash.id, level)
        self.repo.set_grant(grant)
        self.repo.log(AuditEvent("grant", actor.username, f"{user_id}:{dash.id}:{level.name}"))
        return grant

    def revoke(self, actor: User, dashboard_id: int, user_id: int) -> None:
        dash = self._authorized_dashboard(actor, dashboard_id, Permission.ACCESS_GRANT)
        if not self.repo.remove_grant(user_id, dash.id):
            raise NotFoundError("Ce partage n'existe pas : rien à retirer.")
        self.repo.log(AuditEvent("revoke", actor.username, f"{user_id}:{dash.id}"))
