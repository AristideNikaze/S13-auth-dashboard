"""Persistance SQLite : même contrat (`Repository`) que le dépôt en mémoire.

- requêtes TOUJOURS paramétrées (`?`) : aucune concaténation SQL, donc pas d'injection SQL ;
- une connexion partagée protégée par un verrou (FastAPI exécute les routes synchrones dans un pool de threads) ;
- clés étrangères activées, mode WAL pour de meilleures lectures concurrentes.
"""
from __future__ import annotations

import sqlite3
import threading
from datetime import datetime
from typing import Optional

from .models import AccessLevel, AuditEvent, Dashboard, Grant, Role, User

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash   TEXT NOT NULL,
    role            TEXT NOT NULL,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TEXT,
    active          INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS dashboards (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    owner_id    INTEGER NOT NULL REFERENCES users(id),
    description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS grants (
    user_id      INTEGER NOT NULL REFERENCES users(id),
    dashboard_id INTEGER NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
    level        INTEGER NOT NULL,
    PRIMARY KEY (user_id, dashboard_id)
);
CREATE TABLE IF NOT EXISTS revoked_tokens (jti TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS audit (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    action  TEXT NOT NULL,
    actor   TEXT NOT NULL,
    target  TEXT NOT NULL,
    success INTEGER NOT NULL,
    at      TEXT NOT NULL
);
"""


def _user(row) -> Optional[User]:
    if row is None:
        return None
    return User(row["id"], row["username"], row["password_hash"], Role(row["role"]),
                row["failed_attempts"],
                datetime.fromisoformat(row["locked_until"]) if row["locked_until"] else None,
                bool(row["active"]))


class SQLiteRepository:
    def __init__(self, path: str = ":memory:") -> None:
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA foreign_keys = ON")
        if path != ":memory:":
            self._db.execute("PRAGMA journal_mode = WAL")
        self._db.executescript(SCHEMA)
        self._db.commit()

    def close(self) -> None:
        self._db.close()

    def _exec(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self._db.execute(sql, params)
            self._db.commit()
            return cur

    def _all(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._db.execute(sql, params).fetchall()

    def _one(self, sql: str, params: tuple = ()):
        with self._lock:
            return self._db.execute(sql, params).fetchone()

    # --- utilisateurs ---
    def add_user(self, username, password_hash, role) -> User:
        cur = self._exec("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                         (username, password_hash, role.value))
        return User(cur.lastrowid, username, password_hash, role)

    def get_user(self, user_id):
        return _user(self._one("SELECT * FROM users WHERE id = ?", (user_id,)))

    def get_user_by_name(self, username):
        return _user(self._one("SELECT * FROM users WHERE username = ?", (username,)))  # NOCASE

    def update_user(self, user) -> None:
        self._exec(
            "UPDATE users SET role = ?, failed_attempts = ?, locked_until = ?, active = ? WHERE id = ?",
            (user.role.value, user.failed_attempts,
             user.locked_until.isoformat() if user.locked_until else None, int(user.active), user.id))

    def list_users(self):
        return [_user(r) for r in self._all("SELECT * FROM users ORDER BY id")]

    def count_users(self) -> int:
        return self._one("SELECT COUNT(*) AS n FROM users")["n"]

    # --- tableaux de bord ---
    def list_dashboards(self):
        return [Dashboard(r["id"], r["name"], r["owner_id"], r["description"])
                for r in self._all("SELECT * FROM dashboards ORDER BY id")]

    def add_dashboard(self, name, owner_id, description):
        cur = self._exec("INSERT INTO dashboards (name, owner_id, description) VALUES (?, ?, ?)",
                         (name, owner_id, description))
        return Dashboard(cur.lastrowid, name, owner_id, description)

    def get_dashboard(self, dashboard_id):
        r = self._one("SELECT * FROM dashboards WHERE id = ?", (dashboard_id,))
        return Dashboard(r["id"], r["name"], r["owner_id"], r["description"]) if r else None

    def update_dashboard(self, dashboard) -> None:
        self._exec("UPDATE dashboards SET name = ?, description = ? WHERE id = ?",
                   (dashboard.name, dashboard.description, dashboard.id))

    def delete_dashboard(self, dashboard_id) -> None:
        self._exec("DELETE FROM dashboards WHERE id = ?", (dashboard_id,))  # grants : ON DELETE CASCADE

    # --- droits ---
    def set_grant(self, grant) -> None:
        self._exec("INSERT OR REPLACE INTO grants (user_id, dashboard_id, level) VALUES (?, ?, ?)",
                   (grant.user_id, grant.dashboard_id, grant.level.value))

    def remove_grant(self, user_id, dashboard_id) -> bool:
        return self._exec("DELETE FROM grants WHERE user_id = ? AND dashboard_id = ?",
                          (user_id, dashboard_id)).rowcount > 0

    def grants_for(self, dashboard_id):
        return [Grant(r["user_id"], r["dashboard_id"], AccessLevel(r["level"]))
                for r in self._all("SELECT * FROM grants WHERE dashboard_id = ?", (dashboard_id,))]

    def all_grants(self):
        return [Grant(r["user_id"], r["dashboard_id"], AccessLevel(r["level"]))
                for r in self._all("SELECT * FROM grants")]

    # --- jetons révoqués ---
    def revoke_token(self, jti: str) -> None:
        self._exec("INSERT OR IGNORE INTO revoked_tokens (jti) VALUES (?)", (jti,))

    def is_revoked(self, jti: str) -> bool:
        return self._one("SELECT 1 FROM revoked_tokens WHERE jti = ?", (jti,)) is not None

    # --- audit ---
    def log(self, event) -> None:
        self._exec("INSERT INTO audit (action, actor, target, success, at) VALUES (?, ?, ?, ?, ?)",
                   (event.action, event.actor, event.target, int(event.success), event.at.isoformat()))

    def audit_events(self):
        return [AuditEvent(r["action"], r["actor"], r["target"], bool(r["success"]),
                           datetime.fromisoformat(r["at"]))
                for r in self._all("SELECT * FROM audit ORDER BY id")]
