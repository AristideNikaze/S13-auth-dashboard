"""API REST FastAPI + interface web : couche HTTP mince, toute la logique est dans AuthService."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from . import security
from .config import Settings
from .models import (
    AccessLevel,
    AuditOut,
    Dashboard,
    DashboardIn,
    DashboardOut,
    GrantIn,
    GrantOut,
    LoginIn,
    PermissionInfo,
    RefreshIn,
    RegisterIn,
    Role,
    RoleIn,
    RoleInfo,
    RolesOut,
    TokenOut,
    User,
    UserOut,
)
from .rbac import PERMISSION_LABELS, ROLE_DESCRIPTIONS, ROLE_LABELS, ROLE_PERMISSIONS
from .repository import Repository, make_repository
from .service import AuthError, AuthService, ConflictError, ForbiddenError, NotFoundError

STATIC_DIR = Path(__file__).parent / "static"
bearer = HTTPBearer(auto_error=False)

_FIELD_LABELS = {
    "username": "nom d'utilisateur", "password": "mot de passe", "role": "rôle", "name": "nom du tableau",
    "description": "description", "level": "niveau d'accès", "user_id": "utilisateur",
    "refresh_token": "jeton de renouvellement",
}


def french_validation_message(errors: list[dict]) -> str:
    """Traduit les erreurs de validation Pydantic (anglais) en phrases françaises claires."""
    parts = []
    for err in errors:
        field = str(err["loc"][-1]) if err.get("loc") else "valeur"
        label = _FIELD_LABELS.get(field, field)
        kind, ctx = err.get("type", ""), err.get("ctx") or {}
        if kind == "missing":
            msg = "champ obligatoire"
        elif kind == "string_too_short":
            msg = f"trop court (minimum {ctx.get('min_length')} caractères)"
        elif kind == "string_too_long":
            msg = f"trop long (maximum {ctx.get('max_length')} caractères)"
        elif kind == "string_pattern_mismatch":
            msg = "caractères non autorisés (lettres, chiffres, point, tiret et _ uniquement)"
        elif kind in ("enum", "literal_error"):
            msg = "valeur non autorisée"
        elif kind.startswith("int_"):
            msg = "nombre entier attendu"
        else:
            msg = "valeur invalide"
        parts.append(f"{label} : {msg}")
    return "Données invalides — " + " ; ".join(parts) + "."


def create_app(repo: Optional[Repository] = None, settings: Optional[Settings] = None,
               service: Optional[AuthService] = None) -> FastAPI:
    settings = settings or Settings()
    service = service or AuthService(repo or make_repository(), settings)
    app = FastAPI(
        title="Authentification et droits d'accès aux tableaux de bord",
        description="Sujet 13 — LEE Master 1 ID. L'interface web est sur `/`, cette page documente l'API.",
        version="2.0.0",
    )
    app.state.service = service

    # ---- traduction des erreurs métier en codes HTTP + messages français ----
    @app.exception_handler(AuthError)
    async def _auth(_: Request, exc: AuthError):
        return _json(401, str(exc), {"WWW-Authenticate": "Bearer"})

    @app.exception_handler(ForbiddenError)
    async def _forbidden(_: Request, exc: ForbiddenError):
        return _json(403, str(exc))

    @app.exception_handler(NotFoundError)
    async def _notfound(_: Request, exc: NotFoundError):
        return _json(404, str(exc))

    @app.exception_handler(ConflictError)
    async def _conflict(_: Request, exc: ConflictError):
        return _json(409, str(exc))

    @app.exception_handler(security.WeakPasswordError)
    async def _weak(_: Request, exc: security.WeakPasswordError):
        return _json(422, str(exc))

    @app.exception_handler(RequestValidationError)
    async def _invalid(_: Request, exc: RequestValidationError):
        return _json(422, french_validation_message(exc.errors()))

    # ---- dépendances ----
    def svc() -> AuthService:
        return service

    def token_of(creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> str:
        if creds is None:
            raise AuthError("Vous devez d'abord vous connecter.")
        return creds.credentials

    def current_user(token: str = Depends(token_of), s: AuthService = Depends(svc)) -> User:
        return s.authenticate(token)

    def dash_out(s: AuthService, user: User, d: Dashboard) -> DashboardOut:
        owner = s.repo.get_user(d.owner_id)
        return DashboardOut(id=d.id, name=d.name, owner_id=d.owner_id, description=d.description,
                            owner_name=owner.username if owner else "?", my_access=s.access_label(user, d))

    # ---- interface web ----
    @app.get("/", include_in_schema=False)
    def home():
        return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store"})

    # ---- référence : rôles et permissions (publique : sert à l'écran d'inscription) ----
    @app.get("/roles", response_model=RolesOut, tags=["Référence"], summary="Rôles et droits")
    def roles():
        return RolesOut(
            permissions=[PermissionInfo(code=p.value, label=lbl) for p, lbl in PERMISSION_LABELS.items()],
            roles=[RoleInfo(code=r.value, label=ROLE_LABELS[r], description=ROLE_DESCRIPTIONS[r],
                            permissions=[p.value for p in PERMISSION_LABELS if p in ROLE_PERMISSIONS[r]])
                   for r in Role])

    # ---- authentification ----
    @app.post("/auth/register", response_model=UserOut, status_code=201, tags=["Authentification"],
              summary="Créer un compte (avec choix du rôle)")
    def register(body: RegisterIn, s: AuthService = Depends(svc)):
        user = s.register(body.username, body.password, body.role)
        return UserOut(id=user.id, username=user.username, role=user.role)

    @app.post("/auth/login", response_model=TokenOut, tags=["Authentification"], summary="Se connecter")
    def login(body: LoginIn, s: AuthService = Depends(svc)):
        access, refresh = s.login(body.username, body.password)
        return TokenOut(access_token=access, refresh_token=refresh)

    @app.post("/auth/refresh", response_model=TokenOut, tags=["Authentification"],
              summary="Renouveler la session")
    def refresh(body: RefreshIn, s: AuthService = Depends(svc)):
        access, new_refresh = s.refresh(body.refresh_token)
        return TokenOut(access_token=access, refresh_token=new_refresh)

    @app.post("/auth/logout", status_code=204, tags=["Authentification"], summary="Se déconnecter")
    def logout(token: str = Depends(token_of), s: AuthService = Depends(svc)):
        s.logout(token)
        return Response(status_code=204)

    # ---- utilisateurs ----
    @app.get("/users/me", response_model=UserOut, tags=["Utilisateurs"], summary="Mon profil")
    def me(user: User = Depends(current_user)):
        return UserOut(id=user.id, username=user.username, role=user.role)

    @app.get("/users", response_model=list[UserOut], tags=["Utilisateurs"], summary="Annuaire des comptes")
    def users(user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return [UserOut(id=u.id, username=u.username, role=u.role) for u in s.list_users(user)]

    @app.patch("/users/{user_id}/role", response_model=UserOut, tags=["Utilisateurs"],
               summary="Changer le rôle d'un compte (administrateur)")
    def set_role(user_id: int, body: RoleIn, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        t = s.set_role(user, user_id, body.role)
        return UserOut(id=t.id, username=t.username, role=t.role)

    # ---- tableaux de bord ----
    @app.get("/dashboards", response_model=list[DashboardOut], tags=["Tableaux de bord"],
             summary="Lister les tableaux visibles par moi")
    def list_dashboards(user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return [dash_out(s, user, d) for d in s.list_dashboards(user)]

    @app.post("/dashboards", response_model=DashboardOut, status_code=201, tags=["Tableaux de bord"],
              summary="Créer un tableau de bord")
    def create_dashboard(body: DashboardIn, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return dash_out(s, user, s.create_dashboard(user, body.name, body.description))

    @app.get("/dashboards/{dashboard_id}", response_model=DashboardOut, tags=["Tableaux de bord"],
             summary="Consulter un tableau de bord")
    def get_dashboard(dashboard_id: int, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return dash_out(s, user, s.get_dashboard(user, dashboard_id))

    @app.put("/dashboards/{dashboard_id}", response_model=DashboardOut, tags=["Tableaux de bord"],
             summary="Modifier un tableau de bord")
    def update_dashboard(dashboard_id: int, body: DashboardIn, user: User = Depends(current_user),
                         s: AuthService = Depends(svc)):
        return dash_out(s, user, s.update_dashboard(user, dashboard_id, body.name, body.description))

    @app.delete("/dashboards/{dashboard_id}", status_code=204, tags=["Tableaux de bord"],
                summary="Supprimer un tableau de bord")
    def delete_dashboard(dashboard_id: int, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        s.delete_dashboard(user, dashboard_id)
        return Response(status_code=204)

    @app.get("/dashboards/{dashboard_id}/grants", response_model=list[GrantOut], tags=["Tableaux de bord"],
             summary="Voir avec qui un tableau est partagé")
    def list_grants(dashboard_id: int, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return [GrantOut(user_id=g.user_id, username=u.username if u else "?",
                         level="écriture" if g.level is AccessLevel.WRITE else "lecture")
                for g, u in s.list_grants(user, dashboard_id)]

    @app.post("/dashboards/{dashboard_id}/grants", status_code=201, tags=["Tableaux de bord"],
              summary="Partager un tableau avec un compte")
    def grant(dashboard_id: int, body: GrantIn, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        g = s.grant(user, dashboard_id, body.user_id, body.level)
        return {"user_id": g.user_id, "dashboard_id": g.dashboard_id, "level": g.level.name}

    @app.delete("/dashboards/{dashboard_id}/grants/{user_id}", status_code=204, tags=["Tableaux de bord"],
                summary="Retirer un partage")
    def revoke(dashboard_id: int, user_id: int, user: User = Depends(current_user), s: AuthService = Depends(svc)):
        s.revoke(user, dashboard_id, user_id)
        return Response(status_code=204)

    # ---- audit ----
    @app.get("/audit", response_model=list[AuditOut], tags=["Audit"], summary="Journal d'audit (administrateur)")
    def audit(user: User = Depends(current_user), s: AuthService = Depends(svc)):
        return [AuditOut(**e.__dict__) for e in s.audit(user)]

    return app


def _json(status: int, detail: str, headers: Optional[dict] = None):
    return JSONResponse(status_code=status, content={"detail": detail}, headers=headers)


app = create_app()
