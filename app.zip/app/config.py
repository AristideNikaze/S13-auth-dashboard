"""Configuration de l'application (variables d'environnement, jamais de secret en dur en production)."""
import os
from dataclasses import dataclass, field


def _role_choice_default() -> bool:
    # AUTH_ALLOW_ROLE_CHOICE=0 : le rôle demandé à l'inscription est ignoré (mode « production »).
    return os.getenv("AUTH_ALLOW_ROLE_CHOICE", "1") != "0"


@dataclass(frozen=True)
class Settings:
    secret_key: str = field(default_factory=lambda: os.getenv("AUTH_SECRET_KEY", "dev-only-change-me-please-32-bytes!"))
    algorithm: str = "HS256"
    access_ttl_seconds: int = 15 * 60
    refresh_ttl_seconds: int = 7 * 24 * 3600
    max_failed_attempts: int = 5
    lockout_seconds: int = 15 * 60
    # Démonstration : l'utilisateur choisit son rôle en créant son compte (demandé par le sujet).
    allow_role_choice: bool = field(default_factory=_role_choice_default)
