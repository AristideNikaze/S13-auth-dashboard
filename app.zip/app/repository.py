"""Couche d'accès aux données : un contrat (Protocol) + une implémentation en mémoire.

Programmer contre l'interface permet de brancher plus tard SQLite/PostgreSQL
sans toucher au service (inversion de dépendance, Chapitre 6).
"""
from __future__ import annotations

import threading
from typing import Optional, Protocol

from .models import AuditEvent, Dashboard, Grant, User


class Repository(Protocol):
    def add_user(self, username: str, password_hash: str, role) -> User: ...
    def get_user(self, user_id: int) -> Optional[User]: ...
    def get_user_by_name(self, username: str) -> Optional[User]: ...
    def update_user(self, user: User) -> None: ...
    def list_users(self) -> list[User]: ...
    def count_users(self) -> int: ...
    def list_dashboards(self) -> list[Dashboard]: ...
    def add_dashboard(self, name: str, owner_id: int, description: str) -> Dashboard: ...
    def get_dashboard(self, dashboard_id: int) -> Optional[Dashboard]: ...
    def update_dashboard(self, dashboard: Dashboard) -> None: ...
    def delete_dashboard(self, dashboard_id: int) -> None: ...
    def set_grant(self, grant: Grant) -> None: ...
    def remove_grant(self, user_id: int, dashboard_id: int) -> bool: ...
    def grants_for(self, dashboard_id: int) -> list[Grant]: ...
    def all_grants(self) -> list[Grant]: ...
    def revoke_token(self, jti: str) -> None: ...
    def is_revoked(self, jti: str) -> bool: ...
    def log(self, event: AuditEvent) -> None: ...
    def audit_events(self) -> list[AuditEvent]: ...


class InMemoryRepository:
    """Implémentation thread-safe (un verrou protège l'état partagé, Chapitre 4)."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._users: dict[int, User] = {}
        self._dashboards: dict[int, Dashboard] = {}
        self._grants: dict[tuple[int, int], Grant] = {}
        self._revoked: set[str] = set()
        self._audit: list[AuditEvent] = []
        self._next_user = 1
        self._next_dash = 1

    # --- utilisateurs ---
    def add_user(self, username, password_hash, role) -> User:
        with self._lock:
            user = User(self._next_user, username, password_hash, role)
            self._users[user.id] = user
            self._next_user += 1
            return user

    def get_user(self, user_id):
        return self._users.get(user_id)

    def get_user_by_name(self, username):
        with self._lock:
            return next((u for u in self._users.values() if u.username.lower() == username.lower()), None)

    def update_user(self, user) -> None:
        with self._lock:
            self._users[user.id] = user

    def list_users(self):
        with self._lock:
            return sorted(self._users.values(), key=lambda u: u.id)

    def count_users(self) -> int:
        return len(self._users)

    # --- tableaux de bord ---
    def list_dashboards(self):
        with self._lock:
            return list(self._dashboards.values())

    def add_dashboard(self, name, owner_id, description):
        with self._lock:
            dash = Dashboard(self._next_dash, name, owner_id, description)
            self._dashboards[dash.id] = dash
            self._next_dash += 1
            return dash

    def get_dashboard(self, dashboard_id):
        return self._dashboards.get(dashboard_id)

    def update_dashboard(self, dashboard) -> None:
        with self._lock:
            self._dashboards[dashboard.id] = dashboard

    def delete_dashboard(self, dashboard_id) -> None:
        with self._lock:
            self._dashboards.pop(dashboard_id, None)
            self._grants = {k: g for k, g in self._grants.items() if g.dashboard_id != dashboard_id}

    # --- droits ---
    def set_grant(self, grant) -> None:
        with self._lock:
            self._grants[(grant.user_id, grant.dashboard_id)] = grant

    def remove_grant(self, user_id, dashboard_id) -> bool:
        with self._lock:
            return self._grants.pop((user_id, dashboard_id), None) is not None

    def grants_for(self, dashboard_id):
        with self._lock:
            return [g for g in self._grants.values() if g.dashboard_id == dashboard_id]

    def all_grants(self):
        with self._lock:
            return list(self._grants.values())

    # --- jetons révoqués ---
    def revoke_token(self, jti: str) -> None:
        with self._lock:
            self._revoked.add(jti)

    def is_revoked(self, jti: str) -> bool:
        return jti in self._revoked

    # --- audit ---
    def log(self, event) -> None:
        with self._lock:
            self._audit.append(event)

    def audit_events(self):
        with self._lock:
            return list(self._audit)


def make_repository() -> Repository:
    """Choisit le dépôt selon l'environnement : AUTH_DB_PATH défini -> SQLite persistant, sinon mémoire."""
    import os

    path = os.getenv("AUTH_DB_PATH")
    if path:
        from .sqlite_repository import SQLiteRepository

        return SQLiteRepository(path)
    return InMemoryRepository()
