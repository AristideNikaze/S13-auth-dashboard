"""Briques cryptographiques : hachage des mots de passe (bcrypt) et jetons JWT.

Fonctions volontairement PURES (Chapitre 1/8) : faciles à tester sans état caché.
"""
from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import bcrypt
import jwt

from .config import Settings

ACCESS = "access"
REFRESH = "refresh"


class WeakPasswordError(ValueError):
    pass


class InvalidTokenError(Exception):
    pass


def validate_password_policy(password: str) -> None:
    """Politique minimale : 8+ caractères, une majuscule, une minuscule, un chiffre."""
    problems = []
    if len(password) < 8:
        problems.append("8 caractères minimum")
    if not re.search(r"[A-Z]", password):
        problems.append("une majuscule")
    if not re.search(r"[a-z]", password):
        problems.append("une minuscule")
    if not re.search(r"\d", password):
        problems.append("un chiffre")
    if problems:
        raise WeakPasswordError("Mot de passe faible : il faut " + ", ".join(problems))


def hash_password(password: str) -> str:
    # bcrypt gère le sel et le coût ; il tronque à 72 octets, on les borne explicitement.
    rounds = int(os.getenv("AUTH_BCRYPT_ROUNDS", "12"))  # 12 en production ; abaissé dans les tests
    return bcrypt.hashpw(password.encode()[:72], bcrypt.gensalt(rounds=rounds)).decode()


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode()[:72], password_hash.encode())
    except ValueError:
        return False


def create_token(*, user_id: int, role: str, kind: str, settings: Settings, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    ttl = settings.access_ttl_seconds if kind == ACCESS else settings.refresh_ttl_seconds
    payload: dict[str, Any] = {
        "sub": str(user_id),
        "role": role,
        "type": kind,
        "jti": uuid.uuid4().hex,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=ttl)).timestamp()),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)


def decode_token(token: str, *, expected_kind: str, settings: Settings,
                 now: datetime | None = None) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    try:
        # L'algorithme est FIXÉ côté serveur : jamais lu depuis l'en-tête du jeton.
        # L'expiration est vérifiée ci-dessous avec l'horloge INJECTÉE (testable), pas l'heure système.
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm],
                             options={"verify_exp": False, "verify_iat": False,
                                      "require": ["exp", "sub", "jti", "type"]})
    except jwt.PyJWTError as exc:
        raise InvalidTokenError("Session invalide : reconnectez-vous.") from exc
    if payload["exp"] <= int(now.timestamp()):
        raise InvalidTokenError("Session expirée : reconnectez-vous.")
    if payload.get("type") != expected_kind:
        raise InvalidTokenError("Type de jeton incorrect.")
    return payload
